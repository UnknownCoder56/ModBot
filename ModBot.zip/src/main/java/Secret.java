public class Secret {

    private static String token = "ODc4ODQ5NTY2OTE5NzU3OTM1.YSHKcA.e5gnkRWh0CiCDShAEotWgj5q8GY";

    public static String getToken() {
        return token;
    }
}
